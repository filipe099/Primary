var body= document.getElementById(`corpo`)

function mudarBackground(y){
  var y= "a"
  if(y === "a"){
   var y = "b"
   body.style.background= "red"
}
}
